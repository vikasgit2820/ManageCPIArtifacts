import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String

//Remove package from lookup list
    
	def artifactId = message.getProperties().get("artifactIdList").reverse() as Stack
    artifactId.pop()
    artifactId = artifactId.reverse() as Stack
    message.setProperty("artifactIdList", artifactId)
    def artifactNames = message.getProperties().get("artifactNameList").reverse() as Stack
    artifactNames.pop()
    artifactNames = artifactNames.reverse() as Stack
    message.setProperty("artifactNameList", artifactNames)
    
    return message;
	
}