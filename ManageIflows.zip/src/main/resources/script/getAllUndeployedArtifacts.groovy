import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
def Message processData(Message message) {
       map = message.getProperties();
       value = map.get("undeployedArtifact");
       message.setBody(JsonOutput.toJson(value));
       return message;
}