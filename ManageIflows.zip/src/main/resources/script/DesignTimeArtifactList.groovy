import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
  
    def body = message.getBody(java.lang.String) as String
    def json = new JsonSlurper().parseText(body)
    def packageNames = []
    def packageDisplaynames = []
    json.d.results.each{               
    	packageNames.push(it.TechnicalName)
        packageDisplaynames.push(it.DisplayName)
    }    
    message.setProperty("packageNameList", packageNames)
    message.setProperty("packageDisplaynameList", packageDisplaynames)
    return message;
}