import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
def Message processData(Message message) {
     def body = message.getBody(java.lang.String) as String
    def json = new JsonSlurper().parseText(body)
    def artifacts = []
    json.d.results.each{  
        if(it.Id != "ManageIflows")
    	    artifacts.push(it)
    }    
    message.setProperty("artifactsList", artifacts)
    return message;
}