import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def json = new JsonSlurper().parseText(body)
    def artifacts = [:]
    json.d.results.each{               
    	artifacts[it.Id]= [
    		Id:it.Id,
    		Name:it.Name,
            DesigntimePackage:"",
    		VersionRuntime:it.Version,
            VersionDesigntime:"",
            Type:it.Type,
            ExistsRuntime:true,
            ExistsDesigntime:false
    	]
    }    
    message.setProperty("runTimeArtifactList", artifacts)
    return message;
}