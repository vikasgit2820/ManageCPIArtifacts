import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import groovy.json.*;

def Message processData(Message message) {
  
    def body = message.getBody(java.lang.String) as String
    def json = new JsonSlurper().parseText(body)
    def artifacts = message.getProperties().get("runTimeArtifactList")
    def undeployedArtifact ="";
    if(message.getProperties().get("undeployedArtifact")==null)
    {
        undeployedArtifact  = []
    }
    else
    {
    undeployedArtifact   = message.getProperties().get("undeployedArtifact")
    }
   
    json.d.results.each{    
        if (!artifacts.containsKey(it.Name)){
           undeployedArtifact.add([
                Id:it.Name,
                Name:it.DisplayName,
                DesigntimePackage:message.getProperties().get("packageDisplaynameList")[0],
                VersionRuntime:"",
                VersionDesigntime:it.Version,
                Type:(it.Type=="IFlow"?"INTEGRATION_FLOW":(it.Type=="ValueMapping"?"VALUE_MAPPING":it.Type)),
                ExistsRuntime:false,
                ExistsDesigntime:true,
                Status: "Not Started"
            ])
        }      
    }    
     message.setProperty("undeployedArtifact", undeployedArtifact)
   
    //Remove package from lookup list
    def packages = message.getProperties().get("packageNameList").reverse() as Stack
    packages.pop()
    packages = packages.reverse() as Stack
    message.setProperty("packageNameList", packages)
    def packagesDisplay = message.getProperties().get("packageDisplaynameList").reverse() as Stack
    packagesDisplay.pop()
    packagesDisplay = packagesDisplay.reverse() as Stack
    message.setProperty("packageDisplaynameList", packagesDisplay)

    return message;
}